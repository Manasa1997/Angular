import { Component } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms';
 import { FORMERR } from 'dns';
 @Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.css']
 })
export class AppComponent {
  title = 'ng-forms-app';
 
}

//   myForm=new FormGroup({
//     /*firstname:new FormControl("Manasa"),
//     lastname:new FormControl('Myadam')*/
// firstname:new FormControl('',[
// Validators.required,
// Validators.maxLength(10),
// Validators.minLength(3)
// ]),
//     lastname:new FormControl('',[
//       Validators.required,
//       Validators.maxLength(10),
// Validators.minLength(3)
//     ]),
// email:new FormControl('',[
//   Validators.required,
//   Validators.pattern('[A-Za-z]{5}[@][a-z]{5}[.][a-z]{3}')
// ]),
// contact:new FormControl('',[
//   Validators.required,
//   Validators.pattern('[0,6-9]{1}[0-9]{9}')
// ]),
// gender:new FormControl('',[
//   Validators.required
// ]),
// languages:new FormControl('',[
//   Validators.required
// ]),
// address:new FormGroup({
//   city:new FormControl('',[Validators.required,Validators.minLength(3)]),
//   state:new FormControl('',[Validators.required,Validators.minLength(2)])
// })
//   });


// error_messages={
// 'firstname':[
//   {type:'required',message:"field should not be empty"},
//   {type:'maxlength',message:"The characters must be 10"},
//   {type:'minlength',message:"The characters must be 3"}
// ],
// 'lastname':[
//   {
//     type:'required',message:"field should not be empty"
//   },
//   {type:'maxlength',message:"The characters must be 10"},
//   {type:'minlength',message:"The characters must be 3"}
// ],
// 'email':[
//   { type:'required',message:"field should not be empty" },
//   {type:'pattern',message:"It should be in proper pattern"}
// ],


// 'contact':[
//   {type:'required',message:"field should not be empty"},
//   {type:'pattern',message:"The digits must be 10 and should start from 6-9"}
// ],

// 'gender':[
//   {type:'required',message:"Choose one field"}
// ],

// 'languages':[
//   {type:'required',message:"Choose one field"}
  
// ],
// 'city':[
//   {type:'required',message:"field should not be empty"},
//   {type:'minlength',message:"The characters must be 3"}
  
// ],
// 'state':[
//   {type:'required',message:"field should not be empty"},
//   {type:'minlength',message:"The characters must be 2"}
  
// ]
// }

  
// }
