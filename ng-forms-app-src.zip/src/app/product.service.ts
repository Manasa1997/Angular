import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
getAllProducts(){
 return[ {id:1,name:'samsung',model:'Galaxy S9',price:9800},
    {id:2,name:'oppo',model:'Galaxy S9',price:9800},
    {id:3,name:'nokia',model:'Galaxy S9',price:9800},
    {id:4,name:'honor',model:'Galaxy S9',price:9800},
    {id:5,name:'redmi',model:'Galaxy S9',price:9800},
    {id:6,name:'lg',model:'Galaxy S9',price:9800},
    {id:7,name:'vivo',model:'Galaxy S9',price:9800},
    {id:8,name:'one plus',model:'Galaxy S9',price:9800},
    {id:9,name:'iphone',model:'Galaxy S9',price:9800},
    {id:10,name:'moto',model:'Galaxy S9',price:9800},
    
 ]}
  constructor() { }
}
