import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {
employees=[
{id:1,name:'Manasa',mailid:'manasa@gmail.com',salary:25000},
{id:2,name:'Mounika',mailid:'mouni@gmail.com',salary:30000},
{id:3,name:'Niha',mailid:'niha@gmail.com',salary:30000}

]
employee;
selectEmployee(e){
  this.employee=e;
}
  constructor() { }

  ngOnInit() {
  }

}
