
import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-component-app';
  // tickets=1
 /* maxt=10;
  tickets=0;
  update()
  {
    this.maxt=this.maxt-this.tickets;
  }*/
  /*num=0;
  num1=0;
  num2=0;
  add(){
    this.num=this.num1+this.num2;
   
  }sub(){
    this.num=this.num1-this.num2;
  }*/
  Languages=[];
  
  
  add(s){
  this.Languages.push(s);
   
  }
  remove(s){
     //const index=this.Languages.indexOf(s)
    this.Languages.splice(1,1); 
    }

    isBordered=true;

    setBorder(){
      this.isBordered=!this.isBordered;
    }
    d=new Date();
}
