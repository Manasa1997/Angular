import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
products=[
  {id:1,name:'iphone',model:'6s',price:9999,vote:0},
  {id:2,name:'samsung',model:'note8',price:8999,vote:0},
  {id:3,name:'nokia',model:'6',price:7999,vote:0}
]
product;

selectedProduct(p){
  this.product=p;
}
  constructor() { }

  ngOnInit() {
  }

}
