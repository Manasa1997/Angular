import { Component } from '@angular/core';
import { Http,Headers } from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'rest-http-app';

  constructor(private http:Http){}
    product_info;
    status;
    getAllProducts(){
      this.http.get("  http://localhost:3000/products").subscribe((data)=>this.product_info=data.json())
    }

    addproduct(){
var product=JSON.stringify({name:'nokia',model:'8.1',price:29999})
var  header=new Headers({'Content-Type':'application/json'})
this.http.post("http://localhost:3000/products",product,{headers: header}).subscribe(()=>this.status="product has been added successfully")
    }
    updateproduct(){
      var product=JSON.stringify({name:'oppo',model:'f3',price:20000})
            
      var  header=new Headers({'Content-Type':'application/json'})
      this.http.put("http://localhost:3000/products/3",product,{headers: header}).subscribe(()=>this.status="product has been updated successfully")
    

    }

    deleteproduct(){
      this.http.delete("http://localhost:3000/products/3").subscribe(()=>this.status="product has been deleted successfully")
    
    }
  }

