import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-pipes-app';
  languages=['java','pega','react','angular','spring']
  products=[
    {id:1,name:'oppo',model:'f3',price:'5800'},
    {id:2,name:'honor',model:'s7',price:'1800'},
    {id:3,name:'samsung',model:'j7',price:'7800'},
    {id:4,name:'mi',model:'note8',price:'6800'}
  ]
}
