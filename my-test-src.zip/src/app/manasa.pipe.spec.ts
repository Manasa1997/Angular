import { ManasaPipe } from './manasa.pipe';

describe('ManasaPipe', () => {
  it('create an instance', () => {
    const pipe = new ManasaPipe();
    expect(pipe).toBeTruthy();
  });
});
