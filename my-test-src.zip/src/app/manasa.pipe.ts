import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'manasa'
})
export class ManasaPipe implements PipeTransform {
 
  transform(value,c){
    let temp=[];
   for(var i=0;i<value.length;i++){
     if(value[i].name===c)
     {
      temp.push(value[i].name);
      temp.push(value[i].model);
      temp.push(value[i].price);
      return temp;
     }
   }
  }

}

