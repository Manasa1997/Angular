import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string = 'my-test';
  a=[
    {name:"oppo",model:'f3',price:20000},
    {name:"samsung",model:'j7',price:4000},
    {name:"nokia",model:'1600',price:5000}
  ]
  
//   edit(m,j){

// this.a[j].name=m;

edit(m,j){

  this.a[j].model=m;
  

  }
}
