import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string= 'my-ng-app';

  message="Good Mrng"
num=10
names=[
{name:'Jani',country:'Norway'},
{name:'Hege',country:'Sweden'},
{name:'Kai',country:'Denmark'}]
languages=['java','react','angular','pega']

products=[
  {id:1,name:'oppo',model:'f3',price:19500},
  {id:2,name:'honor',model:'6s',price:7500},
  {id:3,name:'iphone',model:'6s',price:9999}
]
m="Myadammanasa"
}
